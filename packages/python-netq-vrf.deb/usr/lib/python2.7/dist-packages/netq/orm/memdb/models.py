# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
import time

from netq.orm import objects, HOSTNAME
from netq.orm.memdb.db import AvlTree
from netq.orm.memdb.query import MemQuery

class MemModel(objects.Model):
    query_cls = MemQuery
    active = objects.Boolean(json_key='active')
    hostname = objects.String(json_key='hostname')
    timestamp = objects.Float(json_key='timestamp')
    deleted = objects.Boolean(json_key='deleted')

    def __init__(self):
        self.active = True
        self.deleted = False
        self.hostname = HOSTNAME
        self.timestamp = time.time()
        super(MemModel, self).__init__()

    @classmethod
    def delete(cls, key, score):
        if key in cls.query.map:
            cls.query.map[key].remove(float(score))
            if cls.query.map[key].empty():
                cls.query.map.pop(key)

    def delete_object(self):
        cls = self.__class__
        key = cls.obj_to_key(self.__dict__)
        score = cls.obj_to_score(self.__dict__)
        cls.delete(key, score)

    @classmethod
    def flush(cls):
        cls.query.map = {}

    @classmethod
    def save(cls, key, score, value):
        if key not in cls.query.map:
            cls.query.map[key] = AvlTree()
        cls.query.map[key].insert(float(score), value)

    def save_object(self):
        cls = self.__class__
        key = cls.obj_to_key(self.__dict__)
        score = cls.obj_to_score(self.__dict__)
        value = cls.obj_to_val(self.__dict__)
        cls.save(key, score, value)


class Lldp(MemModel):
    ifname = objects.String(json_key='ifname')
    peer_hostname = objects.String(json_key='peerHostname')
    peer_ifname = objects.String(json_key='peerIfname')
    lldp_peer_bridge = objects.Boolean(json_key='lldpPeerBridge')
    lldp_peer_router = objects.Boolean(json_key='lldpPeerRouter')
    lldp_peer_os = objects.String(json_key='lldpPeerOS')

    @classmethod
    def key_fmt(cls, key_type=None):
        return (cls.__name__, cls.hostname, cls.ifname, cls.peer_hostname,
                cls.peer_ifname, cls.lldp_peer_bridge, cls.lldp_peer_router,
                cls.lldp_peer_os)

    @classmethod
    def score_fmt(cls, key_type=None):
        return cls.timestamp

    @classmethod
    def val_fmt(cls):
        return None

    def save(self, **kwargs): # pylint: disable=unused-argument
        super(Lldp, self).save(Lldp.obj_to_key(self.__dict__),
                               Lldp.obj_to_score(self.__dict__),
                               True)
