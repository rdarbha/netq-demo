# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
import re

from netq.orm.query import Query, Q


class MemQuery(Query):
    """
    """
    WILDCARD = '.*'

    def __init__(self, cls):
        self.__cls = cls
        self.map = {}

    @staticmethod
    def __escape_kwargs(kwargs):
        escape_kwargs = {}
        for key, kwarg in kwargs.iteritems():
            escape_kwargs[key] = ''.join(
                re.escape(token) for token in re.split('(\W)', str(kwarg))) # pylint: disable=anomalous-backslash-in-string
        return escape_kwargs

    def __range(self, rangeapi, key_type=None, start=-1, end=-1, first=True,
                keys=None, active=None, **kwargs):
        keys = keys or self.__scan_iter(kwargs, key_type=key_type)
        for key in keys:
            if key not in self.map:
                continue
            rangeapifn = getattr(self.map[key], rangeapi)
            values = rangeapifn(start, end)
            for val, score in values:
                obj = self.__cls.key_to_obj(key, key_type=key_type)
                obj = self.__cls.val_to_obj(val, obj=obj)
                if active is not None and obj.active != active:
                    continue
                yield self.__cls.score_to_obj(score, obj=obj,
                                              key_type=key_type)
                if first:
                    break

    def __scan_iter(self, kwargs, key_type=None):
        match = nmatch = None
        if kwargs:
            exclude = kwargs.pop('exclude', None)
            match = '^%s$' % self.__cls.obj_to_key(
                self.__escape_kwargs(kwargs),
                wildcard=self.WILDCARD,
                key_type=key_type
            )
            if isinstance(exclude, Q):
                nmatch = (
                    '^%s$' % self.__cls.obj_to_key(
                        self.__escape_kwargs(exclude.kwargs),
                        wildcard=self.WILDCARD,
                        key_type=exclude.key_type)
                )
        for key in self.map:
            if match is not None:
                if (re.match(match, key) and
                        (nmatch is None or not re.match(nmatch, key))):
                    yield key
            else:
                yield key

    def __val_from_key(self, key):
        if key in self.map:
            for val, score in self.map[key].range(withscores=True):
                yield val, score

    def all(self, key_type=None, timestamp=None):
        if timestamp is None:
            for key in self.__scan_iter({}, key_type=key_type):
                entries = [entry for entry in self.__val_from_key(key)]
                if entries:
                    val, score = entries[-1]
                    obj = self.__cls.key_to_obj(key, key_type=key_type)
                    obj = self.__cls.val_to_obj(val, obj=obj)
                    if not obj.active:
                        continue
                    if score is not None:
                        obj = self.__cls.score_to_obj(score, obj=obj,
                                                      key_type=key_type)
                    yield obj
        else:
            for ele in self.rangebyscore(start=timestamp, end=0,
                                         key_type=key_type,
                                         reverse=True,
                                         first=True):
                yield ele

    def delete(self, key_type=None, **kwargs):
        keys = self.keys(key_type=key_type, **kwargs)
        for key in keys:
            self.map.pop(key)

    def filter(self, key_type=None, timestamp=None, endtimestamp=None,
               **kwargs):
        if timestamp is None:
            for key in self.__scan_iter(kwargs, key_type=key_type):
                entries = [entry for entry in self.__val_from_key(key)]
                if entries:
                    val, score = entries[-1]
                    obj = self.__cls.key_to_obj(key, key_type=key_type)
                    obj = self.__cls.val_to_obj(val, obj=obj)
                    if not obj.active:
                        continue
                    if score is not None:
                        obj = self.__cls.score_to_obj(score, obj=obj,
                                                      key_type=key_type)
                    yield obj
        elif endtimestamp is None:
            for ele in self.rangebyscore(start=timestamp, end=0,
                                         key_type=key_type,
                                         reverse=True,
                                         first=True,
                                         **kwargs):
                yield ele
        else:
            new = list(self.rangebyscore(start=timestamp,
                                         end=0,
                                         key_type=key_type,
                                         reverse=True,
                                         first=True,
                                         **kwargs))
            old = list(self.rangebyscore(start=endtimestamp,
                                         end=0,
                                         key_type=key_type,
                                         reverse=True,
                                         first=True,
                                         **kwargs))
            diff = []
            for ele in new:
                old_ele = next((item for item in old
                                if item.signature() == ele.signature()), None)
                if old_ele is not None and ele.equals(old_ele):
                    continue
                diff.append((ele, old_ele))
            for ele, old_ele in diff:
                if ele.active and (old_ele is None or not old_ele.active):
                    yield ele
            yield None
            for ele, old_ele in diff:
                if ele.active and (old_ele is not None and old_ele.active):
                    yield ele
                    yield old_ele
            yield None
            for ele, old_ele in diff:
                if (not ele.active and
                        (old_ele is not None and old_ele.active)):
                    yield ele

    def keys(self, key_type=None, **kwargs):
        return [key for key in self.__scan_iter(kwargs, key_type=key_type)]

    def get(self, key_type=None, timestamp=None, **kwargs):
        return next(self.filter(timestamp=timestamp, key_type=key_type,
                                **kwargs), None)

    def latest(self, key_type=None, **kwargs):
        key = next(self.__scan_iter(kwargs, key_type=key_type), None)
        if key is None:
            return None
        obj = self.__cls.key_to_obj(key, key_type=key_type)
        value = self.map[key].latest(withscores=True)
        val, score = value
        obj = self.__cls.val_to_obj(val, obj=obj)
        if not obj.active:
            return None
        return self.__cls.score_to_obj(score, obj=obj, key_type=key_type)

    def range(self, key_type=None, reverse=False, start=-1, end=-1, first=True,
              keys=None, **kwargs):
        rangeapi = 'revrange' if reverse else 'range'
        for obj in self.__range(rangeapi, key_type=key_type, start=start,
                                end=end, first=first, keys=keys, **kwargs):
            yield obj

    def rangebyscore(self, key_type=None, reverse=False, start=-1, end=-1,
                     first=True, keys=None, **kwargs):
        rangeapi = 'revrangebyscore' if reverse else 'rangebyscore'
        for obj in self.__range(rangeapi, key_type=key_type, start=start,
                                end=end, first=first, keys=keys, **kwargs):
            yield obj
