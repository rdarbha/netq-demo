# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
import inspect
import json
import weakref


class ORMException(Exception):

    def __init__(self, *args, **kwargs):
        super(ORMException, self).__init__(*args, **kwargs)


class Field(object):
    """ Field object.
    """
    def __init__(self, json_key=None):
        self.name = None
        self.value = None
        self.json_key = json_key

    def to_redis(self, value, # pylint: disable=no-self-use
                 wildcard=None, instance=None): # pylint: disable=unused-argument
        return str(value)

    def from_redis(self, value, # pylint: disable=no-self-use
                   instance=None): #pylint: disable=unused-argument
        return value

    def to_json(self):
        if self.json_key is not None:
            return self.json_key
        else:
            return self.name


class _ModelMeta(type):
    """
    """
    def __new__(mcs, name, bases, class_dict):
        for key, value in class_dict.items():
            if isinstance(value, Field):
                object.__setattr__(value, 'name', key)
        cls = type.__new__(mcs, name, bases, class_dict)

        if class_dict.get('query_cls', None):
            cls.query = class_dict['query_cls'](cls)
        elif getattr(cls, 'query_cls', None):
            cls.query = cls.query_cls(cls)
        return cls


class Model(object):
    """
    """
    __metaclass__ = _ModelMeta
    __PREFIX = 'i_'
    SEPERATOR = '#:#'

    def __init__(self):
        for field in vars(self.__class__).itervalues():
            if isinstance(field, Field):
                setattr(self, field.name, field.value)

    def __getattribute__(self, key):
        field = object.__getattribute__(self, key)
        if isinstance(field, Field):
            return field.from_redis(
                object.__getattribute__(self, self.__PREFIX + field.name),
                instance=self
            )
        else:
            return field

    def __repr__(self):
        attrs = {}
        for _, field in inspect.getmembers(self.__class__,
                                           lambda member:
                                           not inspect.isroutine(member)):
            if isinstance(field, Field):
                attrs[field.name] = getattr(self, field.name, field.value)
        return '%s(%s)' % (self.__class__.__name__,
                           ', '.join('%s=%s' % (k, v)
                                     for k, v in attrs.iteritems()))

    def __setattr__(self, key, value):
        field = object.__getattribute__(self, key)
        if isinstance(field, Field):
            object.__setattr__(self, self.__PREFIX + key,
                               field.to_redis(value, instance=self))
        else:
            object.__setattr__(self, key, value)

    def equals(self, other, exclude=None):
        exclude = exclude or self.__class__.exclude_fmt()
        exclude_names = {field.name for field in exclude}
        for _, field in inspect.getmembers(self.__class__):
            if isinstance(field, Field) and field.name not in exclude_names:
                if getattr(self, field.name) != getattr(other, field.name):
                    return False
        return True

    @classmethod
    def from_json(cls, json_dict):
        obj = cls()
        for _, field in inspect.getmembers(cls,
                                           lambda member:
                                           not inspect.isroutine(member)):
            if isinstance(field, Field):
                value = field.from_redis(json_dict.get(field.to_json(),
                                                       field.value))
                setattr(obj, cls.__PREFIX + field.name, value)
        return obj

    @classmethod
    def exclude_fmt(cls):
        raise NotImplementedError

    @classmethod
    def key_fmt(cls, key_type=None):
        raise NotImplementedError

    @classmethod
    def key_to_obj(cls, key, obj=None, key_type=None):
        fmt = cls.key_fmt(key_type=key_type)
        obj = obj or cls()
        for idx, val in enumerate(key.split(cls.SEPERATOR)):
            # the first entry is the class name
            if idx == 0:
                continue
            cls_field = fmt[idx]
            if isinstance(cls_field, Field):
                setattr(obj, cls_field.name, cls_field.from_redis(val))
        return obj

    @classmethod
    def obj_to_key(cls, inst_dict, wildcard=None, key_type=None):
        args = []
        key = []
        for arg in cls.key_fmt(key_type=key_type):
            if isinstance(arg, Field):
                args.append(arg.name)
                inst_name = cls.__PREFIX + arg.name
                if inst_name in inst_dict:
                    key.append(inst_dict[inst_name])
                elif (arg.name in inst_dict and
                      not isinstance(inst_dict[arg.name], Field)):
                    key.append(arg.to_redis(inst_dict[arg.name],
                                            wildcard=wildcard))
                    inst_dict.pop(arg.name)
                elif wildcard is not None:
                    key.append(wildcard)
            else:
                key.append(arg)
        if wildcard is not None and inst_dict:
            raise ORMException('%s not part of key. Acceptable values '
                               'are %s' % (', '.join(inst_dict),
                                           ', '.join(args)))
        return cls.SEPERATOR.join(key)

    @classmethod
    def obj_to_score(cls, inst_dict, key_type=None):
        arg = cls.score_fmt(key_type=key_type)
        if isinstance(arg, Field):
            inst_name = cls.__PREFIX + arg.name
            if inst_name in inst_dict:
                return float(inst_dict[inst_name])
        return None

    @classmethod
    def obj_to_val(cls, inst_dict):
        val = {}
        for arg in cls.val_fmt():
            if isinstance(arg, Field):
                inst_name = cls.__PREFIX + arg.name
                if inst_name in inst_dict:
                    val[arg.name] = str(inst_dict[inst_name])
        return json.dumps(val)

    @classmethod
    def score_fmt(cls, key_type=None):
        raise NotImplementedError

    @classmethod
    def score_to_obj(cls, score, obj=None, key_type=None):
        obj = obj or cls()
        cls_field = cls.score_fmt(key_type=key_type)
        if cls_field is None:
            return obj
        setattr(obj, cls_field.name, cls_field.from_redis(score))
        return obj

    def signature(self):
        return self.__class__.obj_to_key(self.__dict__)

    def to_json(self):
        output = {}
        for _, field in inspect.getmembers(self.__class__,
                                           lambda member:
                                           not inspect.isroutine(member)):
            if isinstance(field, Field):
                output[field.to_json()] = getattr(self, field.name,
                                                  field.value)
        return output

    @classmethod
    def val_fmt(cls):
        raise NotImplementedError

    @classmethod
    def val_to_obj(cls, val, obj=None):
        obj = obj or cls()
        fmt = cls.val_fmt()
        if fmt is None:
            return obj
        if val != str(True):
            try:
                val = json.loads(val, strict=False)
            except ValueError:
                return obj
            for idx, arg in enumerate(fmt):
                if isinstance(arg, Field):
                    cls_field = fmt[idx]
                    arg_value = val.get(cls_field.name, cls_field.value)
                    setattr(obj, cls_field.name,
                            cls_field.from_redis(arg_value))
        return obj


class Boolean(Field):

    __ALLOWED = bool

    def __init__(self, json_key=None):
        super(Boolean, self).__init__(json_key=json_key)
        self.value = False

    def to_redis(self, value, wildcard=None, **_):
        if wildcard is not None and value == wildcard:
            return value
        if isinstance(value, (str, int)):
            value = self.from_redis(str(value))
        elif not isinstance(value, self.__ALLOWED):
            raise RuntimeError('Value %s(%s) should be of type(s) %s but is '
                               'of type %s' % (self.name, value,
                                               self.__ALLOWED, type(value)))
        return '1' if value else '0'

    def from_redis(self, value, **_):
        if isinstance(value, self.__ALLOWED):
            return value
        if value not in ['0', '1', 'True', 'False']:
            raise RuntimeError('Value %s(%s) should be a bool' %
                               (self.name, value))
        return value in ['1', 'True']


class Float(Field):

    __ALLOWED = float

    def __init__(self, json_key=None):
        super(Float, self).__init__(json_key=json_key)
        self.value = 0.0

    def to_redis(self, value, wildcard=None, **_):
        if wildcard is not None and value == wildcard:
            return value
        if isinstance(value, str):
            try:
                value = self.from_redis(value)
            except Exception:
                raise RuntimeError('Value %s should be an float' % self.name)
        if not isinstance(value, self.__ALLOWED):
            raise RuntimeError('Value %s(%s) should be of type(s) %s but is '
                               'of type %s' % (self.name, value,
                                               self.__ALLOWED, type(value)))
        return str(value)

    def from_redis(self, value, **_):
        return float(value)


class Integer(Field):

    __ALLOWED = int

    def __init__(self, json_key=None):
        super(Integer, self).__init__(json_key=json_key)
        self.value = 0

    def to_redis(self, value, wildcard=None, **_):
        if wildcard is not None and value == wildcard:
            return value
        if isinstance(value, str):
            try:
                value = self.from_redis(value)
            except Exception:
                raise RuntimeError('Value %s should be an integer' % self.name)
        if not isinstance(value, self.__ALLOWED):
            raise RuntimeError('Value %s(%s) should be of type(s) %s but is '
                               'of type %s' % (self.name, value,
                                               self.__ALLOWED, type(value)))
        return str(value)

    def from_redis(self, value, **_):
        return int(value)

class Long(Field):

    __ALLOWED = long
    __ALSO_ALLOWED = int

    def __init__(self, json_key=None):
        super(Long, self).__init__(json_key=json_key)
        self.value = 0

    def to_redis(self, value, wildcard=None, **_):
        if wildcard is not None and value == wildcard:
            return value
        if isinstance(value, str):
            try:
                value = self.from_redis(value)
            except Exception:
                raise RuntimeError('Value %s should be an long' % self.name)
        if (not isinstance(value, self.__ALLOWED) and
            not isinstance(value, self.__ALSO_ALLOWED)):
            raise RuntimeError('Value %s(%s) should be of type(s) %s but is '
                               'of type %s' % (self.name, value,
                                               self.__ALLOWED, type(value)))
        return str(value)

    def from_redis(self, value, **_):
        return long(value)


class Json(Field):

    __ALLOWED = (dict, list, tuple)

    def __init__(self, json_key=None):
        super(Json, self).__init__(json_key=json_key)
        self.__cache = weakref.WeakKeyDictionary()
        self.value = {}

    def to_redis(self, value, wildcard=None, instance=None):
        if wildcard is not None and value == wildcard:
            return value
        if isinstance(value, str):
            try:
                _ = self.from_redis(value)
            except Exception:
                raise RuntimeError('Value %s should be json serializable' %
                                   self.name)
            else:
                return value
        elif not isinstance(value, self.__ALLOWED):
            raise RuntimeError('Value %s(%s) should be of type(s) %s but is of'
                               ' type %s' % (self.name, value,
                                             self.__ALLOWED, type(value)))
        if instance is not None:
            self.__cache[instance] = value
        return json.dumps(value)

    def from_redis(self, value, instance=None):
        if isinstance(value, self.__ALLOWED):
            return value
        elif instance in self.__cache:
            return self.__cache[instance]
        result = json.loads(value)
        if instance is not None:
            self.__cache[instance] = result
        return result


class String(Field):

    __ALLOWED = str

    def __init__(self, json_key=None):
        super(String, self).__init__(json_key=json_key)
        self.value = ''

    def to_redis(self, value, wildcard=None, **_):
        if wildcard is not None and value == wildcard:
            return value
        if not isinstance(value, self.__ALLOWED):
            raise RuntimeError('Value %s(%s) should be of type(s) %s but is of'
                               ' type %s' % (self.name, value,
                                             self.__ALLOWED, type(value)))
        return value.decode('latin-1').encode('utf-8')

    def from_redis(self, value, **_):
        return str(value)


class MacAddress(Field):

    __ALLOWED = str

    def __init__(self, json_key=None):
        super(MacAddress, self).__init__(json_key=json_key)
        self.value = ''

    def to_redis(self, value, wildcard=None, **_):
        if wildcard is not None and value == wildcard:
            return value
        if not isinstance(value, self.__ALLOWED):
            raise RuntimeError('Value %s(%s) should be of type(s) %s but is of'
                               ' type %s' % (self.name, value,
                                             self.__ALLOWED, type(value)))
        val = value.replace(':', '').replace('.', '').strip().lower()
        return ':'.join(val[i:i+2] for i in range(0, len(val), 2))

    def from_redis(self, value, **_):
        return str(value)
