# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA
import os

from redis.client import Script

from netq.orm import HOSTNAME
from netq.orm.redisdb import Connection


class _Scripts(object):

    __DIRNAME = os.path.dirname(__file__)

    def __init__(self):
        requires_luabit = ['lpm_script']
        requires_utils = ['lpm_script']
        with open(os.path.join(_Scripts.__DIRNAME, 'bit.lua'), 'r') as fd:
            luabit = fd.read()
        with open(os.path.join(_Scripts.__DIRNAME, 'utils.lua'), 'r') as fd:
            utils = fd.read()
        for name, snippet in self.__get_lua_funcs():
            snip = ''
            if name in requires_luabit:
                snip += luabit
            if name in requires_utils:
                snip += utils
            snip += snippet
            self.__create_lua_method(name, snip)

    @staticmethod
    def __get_lua_funcs():
        """Returns the name / code snippet pair for each Lua function
        in the atoms.lua file.
        """
        with open(os.path.join(_Scripts.__DIRNAME, 'atoms.lua'), 'r') as fd:
            for func in fd.read().strip().split('function '):
                if func:
                    bits = func.split('\n', 1)
                    name = bits[0].split('(')[0].strip()
                    snippet = bits[1].rsplit('end', 1)[0].strip()
                    yield name, snippet

    def __create_lua_method(self, name, snippet):
        """Registers the code snippet as a Lua script, and binds the
        script to the client as a method that can be called with
        the same signature as regular client methods, eg with a
        single key arg.
        """
        script = Script(HOSTNAME, snippet)

        def method(keys, args, client=None):
            return script(keys=keys, args=args,
                          client=client or Connection.REDIS)
        setattr(self, name, method)

_scripts = _Scripts() # pylint: disable=invalid-name
count_script = _scripts.count_script # pylint: disable=invalid-name
delregex_script = _scripts.delregex_script # pylint: disable=invalid-name
gc_script = _scripts.gc_script # pylint: disable=invalid-name
keys_script = _scripts.keys_script # pylint: disable=invalid-name
lpm_script = _scripts.lpm_script # pylint: disable=invalid-name
scanregex_script = _scripts.scanregex_script # pylint: disable=invalid-name
update_counters_script = _scripts.update_counters_script # pylint: disable=invalid-name

__all__ = ['count_script', 'gc_script', 'lpm_script', 'scanregex_script',
           'delregex_script', 'keys_script', 'update_counters_script']
