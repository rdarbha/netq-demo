# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from abc import ABCMeta, abstractmethod


class Q(object):

    def __init__(self, key_type=None, **kwargs):
        self.key_type = key_type
        self.kwargs = kwargs

class Query(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def all(self, key_type=None, timestamp=None):
        raise NotImplementedError

    @abstractmethod
    def delete(self, key_type=None, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def filter(self, key_type=None, timestamp=None, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def keys(self, key_type=None, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def get(self, key_type=None, timestamp=None, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def latest(self, key_type=None, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def range(self, key_type=None, reverse=False, start=-1, end=-1, first=True,
              **kwargs):
        raise NotImplementedError

    @abstractmethod
    def rangebyscore(self, key_type=None, reverse=False, start=-1, end=-1,
                     first=True, **kwargs):
        raise NotImplementedError
