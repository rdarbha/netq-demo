# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2016 Cumulus Networks, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc.
# 51 Franklin Street, Fifth Floor
# Boston, MA  02110-1301, USA.
from __future__ import absolute_import

import nlmanager.nlpacket

class BgColors(object):
    """ Background Colors
    """
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    RED = '\033[91m'
    GRAY = '\033[90m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    COLORS = (BLUE, BOLD, GRAY, GREEN, RED, YELLOW)

    def __init__(self):
        raise NotImplementedError


class Daemons(object):
    """ Daemons running on the system
    """
    BGPD = 'bgpd'
    CLAG = 'clagd'
    LLDP = 'lldpd'
    MISC = 'misc'
    MSTPD = 'mstpd'
    OSPFD = 'ospfd'
    OSPF6D = 'ospf6d'
    ZEBRA = 'zebra'

    def __init__(self):
        raise NotImplementedError


class DefaultPaths(object):

    CONF_FILE = '/etc/netq/netq-agent.conf'
    DBCONFIG = '/etc/netq/netq-agent-commands.json'
    DBCONFIG_RUNNING = '/etc/netq/netq-agent-running.json'
    INTERFACE_FILE = '/etc/network/interfaces'
    PID_FILE = '/var/run/netq-agent.pid'
    UDS_FILE = '/var/run/netq-agent.sock'

    def __init__(self):
        raise NotImplementedError


class DiffState(object):

    ADDED = 0
    MODIFIED = 1
    DELETED = 2

    MAP = {
        ADDED: 'Addded',
        MODIFIED: 'Modified',
        DELETED: 'Deleted'
    }

    def __init__(self):
        raise NotImplementedError


class Heartbeat(object):
    """ These are shared across netq-agent and netq
    """
    LIVELINESS_RATE = 30
    HEARTBEAT_DEATH = 3 * LIVELINESS_RATE

    def __init__(self):
        raise NotImplementedError


class InterfaceState(object):
    """ Interface state
    """
    UP = 'up'
    DOWN = 'down'

    def __init__(self):
        raise NotImplementedError


class LinkType(object):
    """Link types such as vxlan, bridge etc.
    """
    BOND = 'bond'
    BRIDGE = 'bridge'
    ETH = 'eth'
    IGNORE = 'ignore'
    LOOPBACK = 'loopback'
    MACVLAN = 'macvlan'
    SWP = 'swp'
    VLAN = 'vlan'
    VXLAN = 'vxlan'
    VRF = 'vrf'


class RouteType(object):
    """Netlink route types imported from nlmanager
    """

    RTN_LOCAL = nlmanager.nlpacket.Route.RTN_LOCAL
    RTN_BLACKHOLE = nlmanager.nlpacket.Route.RTN_BLACKHOLE
    RTN_PROHIBIT = nlmanager.nlpacket.Route.RTN_PROHIBIT
    RTN_UNREACHABLE = nlmanager.nlpacket.Route.RTN_UNREACHABLE


class LogDestination(object):
    """Destination for log messages.
    """
    SYSLOG = 'syslog'
    STDOUT = 'stdout'
    LOGFILE = 'logfile'

    def __init__(self):
        raise NotImplementedError


class NeighborState(object):
    """ IP Neighbor state
    """
    UPDATE = 1
    DELETE = 2
    IGNORE = 3

    def __init__(self):
        raise NotImplementedError


class NetDevFmt(object):

    IFACE = 0
    RX_BYTES = 1
    RX_PKTS = 2
    RX_ERR = 3
    RX_DRP = 4
    RX_FIFO = 5
    RX_FRAME = 6
    RX_COMP = 7
    RX_MCAST = 8
    TX_BYTES = 9
    TX_PKTS = 10
    TX_ERR = 11
    TX_DRP = 12
    TX_FIFO = 13
    TX_COLL = 14
    TX_CARR = 15
    TX_COMP = 16

    def __init__(self):
        raise NotImplementedError


class Platform(object):
    """ Platform
    """
    CUMULUS = 'cumulus'
    LINUX = 'linux'
    UNKNOWN = 'UNKNOWN'
    VX = 'vx'


class Protocol(object):
    """ Protocols
    """
    KERNEL = 'kernel'
    ZEBRA = 'zebra'

    MAP = {
        'RT_PROT_KERNEL': KERNEL,
        'RT_PROT_ZEBRA': ZEBRA
    }

    def __init__(self):
        raise NotImplementedError


class RedisKeyType(object):
    """Redis Key Types
    """
    HASH = 'hash'
    LIST = 'list'
    SET = 'set'
    ZSET = 'zset'
    STRING = 'string'

    def __init__(self):
        raise NotImplementedError


class RunningService(object):
    """Service name
    """
    ACLINIT = 'aclinit'
    ACLTOOL = 'acltool'
    ARP_REFRESH = 'arp_refresh'
    CLAGD = 'clagd'
    DOCKER = 'docker'
    LEDMGRD = 'ledmgrd'
    LLDPD = 'lldpd'
    MSTPD = 'mstpd'
    NTP = 'ntp'
    POED = 'poed'
    PORTWD = 'portwd'
    PTMD = 'ptmd'
    PWMD = 'pwmd'
    RSYSLOG = 'rsyslog'
    SMOND = 'smond'
    SSH = 'ssh'
    SWITCHD = 'switchd'
    QUAGGA = 'quagga'
    VXRD = 'vxrd'
    VXSND = 'vxsnd'
    WATCHDOG = 'wd_keepalive'
